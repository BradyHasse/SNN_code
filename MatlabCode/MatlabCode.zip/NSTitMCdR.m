%Neural State Transitions in the Motor Cortex during Reaching
CodeDir = 'C:\Users\BAH150\.spyder-py3\Brian2\Brady';  % Set up the directory here
addpath([CodeDir '\MatlabCode\util'])  %Where do all of the functions live?
ClearCloseClc()
% Set up environment variables and constants
Monk = 'C';  % Set the monk up here. Options: 'C' or 'N'
[colors, MI, Mkind, TargetDir_N, PD_N, PD_N2] = setupEnvironment(Monk, CodeDir);%set example neuron in here

%% load in data for PCA from actual (Figure 1)
ClearCloseClc()

histo_allA = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_histo_all_actual_%s.mat', CodeDir, Monk, Monk, MI{2,Mkind}));
histo_allP = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_histo_all_%s.mat', CodeDir, Monk, Monk, MI{2,Mkind}));
histo_all = histo_allA.histo_all;%  #bins x #targets x #units - average actual    firing rates
histo_allP = histo_allP.histo_all;% #bins x #targets x #units - average predicted firing rates
STA = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_STA_pot_%s_%s.mat', CodeDir, Monk, Monk,MI{1,Mkind}, MI{2,Mkind}));

mean_ev = histo_allA.mean_ev;
xax_labels = histo_allA.xax_labels;
%% Plot firing rates (actual vs predicted)

savePath = sprintf('%s\\Figures\\Monk_%s\\FRs\\', CodeDir, Monk);
aphist = squeeze(max([histo_all; histo_allP],[],[1,2]));
ylimset = ceil((aphist+0.05*aphist)./5).*5; ylimset =[zeros(size(ylimset)) ylimset];
plotFiringRates(xax_labels*1000, histo_all , ylimset, (mean_ev([7,12,10])*1000)-200, 'Firing Rate (spk/sec)', 'Time (msec)', savePath, 'A',colors, MI, Mkind);
plotFiringRates(xax_labels*1000, histo_allP, ylimset, (mean_ev([7,12,10])*1000)-200, 'Firing Rate (spk/sec)', 'Time (msec)', savePath, 'P',colors, MI, Mkind);
%with patches
plotRatesPatches(xax_labels*1000, histo_allP , ylimset, (mean_ev([7,12,10])*1000)-200, 'Firing Rate (spk/sec)', 'Time (msec)', savePath, 'A',colors, STA, MI, Mkind);

%% Perform Rotated PCA on the data
for i = 1:2% for actual and predicted
    if i == 1
        rs = performRotatedPCA(histo_all);
        AorP = "Actual";
    else
        rs = performRotatedPCA(histo_allP);
        AorP = "Predicted";
    end
    
    % Save the rotated PCA results
    save(sprintf('%s\\Data\\Monk%s\\Monk%s_rPCA_%s.mat', CodeDir, Monk,AorP), 'rs');
    
    % Plot the rotated PCA components
    savePath = sprintf('%s\\Figures\\Monk_%s\\rPCA', CodeDir, Monk);
    plotRotatedPCATrajectories(rs, mean_ev, xax_labels*1000,colors, savePath,AorP);
    
    % Plot three pairs of PCA scores 2D plots
    plotRotatedPCATrajectories2d(rs,colors, savePath,AorP);
end
%% load in data for input FR, weights, and actual vs predicted FR (Figure 3)
ClearCloseClc()
input_FR = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_input_FR_%s.mat', CodeDir, Monk, Monk, MI{2,Mkind}));
weights = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_weights_all_%s.mat', CodeDir, Monk, Monk, MI{2,Mkind}));
histoin = input_FR.histoin;% #bins x #targets x #inputgroups - average input firing rates for one example input unit from each group
mean_evin = input_FR.mean_evin;
xax_labelsin = input_FR.xax_labelsin;
%% plot input unit firing rates
savePath = sprintf('%s\\Figures\\Monk_%s\\Input_FRs\\', CodeDir, Monk);
ylimset = [zeros(size(histoin, 3),1), repmat(ceil((max(histoin,[],'all')+0.05*max(histoin,[],'all'))/5)*5, size(histoin, 3),1)];
plotFiringRates(xax_labelsin*1000, histoin , ylimset, (mean_evin([7,12,10])*1000)-200, 'Firing Rate (spk/sec)', 'Time (msec)', savePath, 'Inputs',colors);

%% plot weights
savePath = sprintf('%s\\Figures\\Monk_%s\\Weights\\', CodeDir, Monk);
weights = permute(weights,[3,2,1]);
col2use = [1,0,0,1;0,1,0,1;0,0,1,1;0,0,0,1];
ylimset = squeeze([min(weights,[],[1,2]),max(weights,[],[1,2])])';
ylimset = ylimset+diff(ylimset')'*[-0.05 0.05];
plotFiringRates(PD_N2*(180/pi), weights , ylimset, 0*mean_evin([7,12,10]), 'Weight (a.u)', 'Preferred Direction of Input Unit (deg)', savePath, '_weights',col2use, MI, Mkind);


%% make actual vs predicted graphs
%done in code for figure 1
%% load in data for STA figure and predicted spikes histogram (Figure 4)
ClearCloseClc()
STA = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_STA_pot_%s_%s.mat', CodeDir, Monk, Monk,MI{1,Mkind}, MI{2,Mkind}));
causal_in = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_EPermeg1_%s_20ms_%s.mat', CodeDir, Monk, Monk,MI{1,Mkind}, MI{2,Mkind}));
CTS_in =    importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_EAccmeg1_%s_20ms_%s.mat', CodeDir, Monk, Monk,MI{1,Mkind}, MI{2,Mkind}));
weights =   importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_weights_%s_%s.mat', CodeDir, Monk, Monk,MI{1,Mkind}, MI{2,Mkind}));

sta = STA.sta_pot;
threshold = STA.threshold;
%% Make 20ms STA figure
savePath = sprintf('%s\\Figures\\Monk_%s\\STA', CodeDir, Monk);
XTick = -20:2.5:0;
XTickL = cellstr(string(XTick));
plotSTA(sta, threshold, XTick, XTickL, (-199:0)/10, 'Membrane Potential (a.u.)', savePath, '20ms');

%% Make 5ms STA figure
XTick = -5:1:0;
XTickL = cellstr(string(XTick));
plotSTA(sta(:, end-49:end), threshold, XTick, XTickL, (-49:0)/10, 'Membrane Potential (a.u.)', savePath, '05ms');

%% surface plots for causal inputs
savePath = sprintf('%s\\Figures\\Monk_%s\\SurfacePlots', CodeDir, Monk);
[causal_in2, SCI2] = causalStruct2Mat(causal_in);
[CTS_in2, ~] = causalStruct2Mat(CTS_in);%16x90x2x4x3 - target x input x range (trigger or build-up) x input gorup x analysis epoch

weights2 = permute(weights,[3,2,4,1,5]);
weights2 = repmat(weights2, SCI2(1),1,SCI2(3),1,SCI2(5));

causal_in2w = weights2.*causal_in2;%with weights, membrane potential
causal_in2(isnan(causal_in2))=0;

causal_smoothw = circularsmooth(causal_in2w,10);
causal_smooth =  circularsmooth(causal_in2 ,10);
%save data toa  new format for Andy
% for k = 1:SCI2(3) 
%     CScell = cell(SCI2(4), SCI2(5));
%     CScellw = cell(SCI2(4), SCI2(5));
%     for i = 1:SCI2(4)
%         for j = 1:SCI2(5)
%             CScell{i,j} = causal_smooth(:,:,k,i,j);
%             CScellw{i,j} = causal_smoothw(:,:,k,i,j);%weighted contribution
%         end
%     end
%     save([CodeDir '\Data\' 'Monk' Monk '_' sprintf('causalS_%02ims', k) '.mat'],'CScell')
%     save([CodeDir '\Data\' 'Monk' Monk '_' sprintf('WeightedContribution_%02ims', k) '.mat'],'CScellw')
% end

%Plot individual imagesc and as subplots
for k = 1:size(causal_smoothw,3)%for each window length (trigger and build-up)
    % mat_pre = squeeze(causal_smooth(:,:,k,:,:))*100; %comment out one of these two
    mat_pre = squeeze(causal_smoothw(:,:,k,:,:));
    surfaces_3x4(mat_pre, k,savePath)
end
%% Weights and firing rates of inputs triggering an output spike.
ClearCloseClc()

triggerFRW = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_triggerFRW_%s.mat', CodeDir, Monk, Monk, MI{2,Mkind}));
trigger_histogram(triggerFRW,Monk, CodeDir)

%% analysis of causal inputs
ClearCloseClc()

All_units_CI = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_EPermeg1_All_Units_20ms_%s.mat', CodeDir, Monk, Monk, MI{2,Mkind}));
All_units_CTS = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_EAccmeg1_All_Units_20ms_%s.mat', CodeDir, Monk, Monk, MI{2,Mkind}));
All_weights = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_weights_all_%s.mat', CodeDir, Monk, Monk, MI{2,Mkind}));

TargetDir_N2 = linspace(0, 2*pi-((2*pi)/16), 16);
PD_N2 = linspace(0, 2*pi-((2*pi)/90), 90);

fields = fieldnames(All_units_CI);
fields2 = fieldnames(All_units_CTS);
All_units_CI2 = [];
All_units_CTS2 = [];
for g = 1:length(fields)
    All_units_CI2 = cat(5,All_units_CI2,All_units_CI.(fields{g}));
    All_units_CTS2 = cat(5,All_units_CTS2,All_units_CTS.(fields2{g}));
end
All_units_CI2(isnan(All_units_CI2))=0;
All_units_CTS2(isnan(All_units_CTS2))=0;

AU_CTS_cell = cell(size(All_units_CTS2,1), size(All_units_CTS2,4), size(All_units_CTS2,5));%Raw spike counts
AU_CI_cell = cell(size(All_units_CI2,1), size(All_units_CI2,4), size(All_units_CI2,5));%spike probability
AU_MP_cell = cell(size(All_units_CI2,1), size(All_units_CI2,4), size(All_units_CI2,5));%weighted contribution

for i = 1:size(AU_CTS_cell,1)
    for ii = 1:size(AU_CTS_cell,2)
        for iii = 1:size(AU_CTS_cell,3)
            AU_CTS_cell{i,ii,iii} = squeeze(All_units_CTS2(i,:,:,ii,iii));
            AU_CTS_cell{i,ii,iii} = interp1(PD_N2,AU_CTS_cell{i,ii,iii}',TargetDir_N2);

            AU_CI_cell{i,ii,iii} = squeeze(All_units_CI2(i,:,:,ii,iii));
            AU_CI_cell{i,ii,iii} = interp1(PD_N2,AU_CI_cell{i,ii,iii}',TargetDir_N2);

            AU_MP_cell{i,ii,iii} = squeeze(All_units_CI2(i,:,:,ii,iii)).*repmat(squeeze(All_weights(i,ii,:))',size(All_units_CI2,2),1);
            AU_MP_cell{i,ii,iii} = interp1(PD_N2,AU_MP_cell{i,ii,iii}',TargetDir_N2);
        end
    end
end

save(sprintf('%s\\Data\\Monk%s\\Monk%s_AU_CTS_cell.mat', CodeDir, Monk, Monk),'AU_CTS_cell')
save(sprintf('%s\\Data\\Monk%s\\Monk%s_AU_CI_cell.mat',  CodeDir, Monk, Monk),'AU_CI_cell')
save(sprintf('%s\\Data\\Monk%s\\Monk%s_AU_MP_cell.mat',  CodeDir, Monk, Monk),'AU_MP_cell')

%% Global Diagonal test for causal heatmaps
ClearCloseClc()

AU_MP_cell = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_AU_MP_cell.mat',  CodeDir, Monk, Monk));
%units x input group x epoch cell, containing 16x16 input unit x target

%innitialise variables for loop
TargetDir_N2 = linspace(0, 2*pi-((2*pi)/16), 16);
ideal_movement_matrix = [cos(TargetDir_N2)',sin(TargetDir_N2)'];%for cosine fit
num_units = size(AU_MP_cell,1);
num_tar = size(AU_MP_cell{1,1},1);
ratio = zeros(num_units, size(AU_MP_cell,3),size(AU_MP_cell,2)-1);%how much of the contribution is on the diagonal vs rest of the surface?
ratioNaN = false(num_units, size(AU_MP_cell,3),size(AU_MP_cell,2)-1);%any NaN present? - ei, no spikes in reach direction
r2_diag = zeros(num_units, size(AU_MP_cell,3),size(AU_MP_cell,2)-1);%cosine fit r2 score
pd_diag = cell(num_units, size(AU_MP_cell,3),size(AU_MP_cell,2)-1);%for the cosine fit
bootp = zeros(num_units, size(AU_MP_cell,3),size(AU_MP_cell,2)-1);%rank (0-1) of actual diagonal among random 
diagl = zeros(num_units, size(AU_MP_cell,3),size(AU_MP_cell,2)-1,size(AU_MP_cell{1,1},1));%diagonal values


for unit = 1:num_units
    for epoch = 1:size(AU_MP_cell,3)
        for inputs = 1:size(AU_MP_cell,2)-1%dont use non-directional input
            values = AU_MP_cell{unit,inputs,epoch};
            fr = diag(values);
            d_sum = sum(abs(fr),"omitnan");
            total_sum = sum(abs(values),'all',"omitnan");   %sum of all contributions
            ratio(unit,epoch,inputs) = d_sum/total_sum;%how much of the contribution is on the diagonal?
            diagl(unit,epoch,inputs,:) = fr;
            if any(all(values == 0))   %Only select those heatmaps that contain at least one output spike in all movement directions 
                ratioNaN(unit,epoch,inputs) = true;
            end

            [B, BINT, R, RINT, STATS] = regress(fr, [ones(num_tar,1) ideal_movement_matrix]);
            r2_diag(unit,epoch,inputs) = STATS(1);
            pd_diag{unit,epoch,inputs} = B;
%             y2 = B(1) + B(2)*ideal_movement_matrix(:,1) + B(3)*ideal_movement_matrix(:,2);

            %Diagonal Boot Test - prob of diag ratio compared to random
            iratio = zeros(10000,1);
            for iter = 1:size(iratio,1)
                r = randperm(size(fr,1));
                c = randperm(size(fr,1));
                idx=sub2ind(size(values),r,c);
                iratio(iter) = sum(abs(values(idx)),"omitnan"); %pick 16 random contributions
            end
            iratio = iratio/total_sum;  %generate random ratio
            r_order = sort(iratio); %rank order the random ratios
            I=sum(ratio(unit,epoch,inputs)<r_order);  %find the closest match of actual to random-ranked ratio
            bootp(unit,epoch,inputs) = (I+1)/(size(iratio,1)+1);
        end
    end
end
badunits = all(ratioNaN,[2,3]);
ratio2 = ratio;bootp2 = bootp;r2_diag2 = r2_diag;ratioNaN2 = ratioNaN;
% ratio2(ratioNaN) = NaN;%remove ratios with no spikes in some reach directions
% bootp2(ratioNaN) = NaN;%remove ratios with no spikes in some reach directions
% r2_diag2(ratioNaN) = NaN;%remove ratios with no spikes in some reach directions
% [M,bootpamsk] = max(ratio2,[],[2,3],"omitnan",'linear');%find the best score for each unit.
% bootpamsk = bootpamsk(~isnan(M));%remove those without a spike in reaches to each target
% M = M(~isnan(M));%remove those without a spike in reaches to each target
% BestRankForUnits = bootp(bootpamsk);
% BestR2ForUnits = r2_diag(bootpamsk);
ratioNaN2 = ratioNaN2(~badunits,:,:);
bootp2 = bootp2(~badunits,:,:);
bootp3 = bootp2;
bootp3(ratioNaN2) = NaN;
r2_diag2 = r2_diag2(~badunits,:,:);
% WorstBestBoot = min(max(bootp2,[],[2,3]));
% WorstBestR2 = min(max(r2_diag2,[],[2,3]));

mean_boot_p = squeeze(mean(bootp2));
mean_boot_p_matched = mean(diag(mean_boot_p));
mean_boot_p_unmatched = mean(mean_boot_p(~eye(size(mean_boot_p))));

max_boot_p = squeeze(max(bootp3));
max_boot_p_matched = max(diag(max_boot_p));
max_boot_p_unmatched = mean(max_boot_p(~eye(size(max_boot_p))));


%% example showing how weights are trained.
ClearCloseClc()
EWT = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_example_weight_training_%s.mat', CodeDir, Monk, Monk,MI{2,Mkind}));

OE = EWT.outexample;
IE = EWT.inexample;

axmax = 1.2*max([OE IE]);
t = 0.0001:0.0001:axmax;
tc = 0.020;%20ms tau
y0 = 0.01;%APre = 0.01
yt = y0*exp(-t/tc);
yt = [flip(yt), y0,yt];
t = [0 t];
t2 = 0*t;
w = t2;%keep track of weights
midind = length(t2);

for i = 1:length(IE)
    i2 = round(IE(i)/.0001);
    t2 = t2 + yt((midind-i2):(midind*2-i2-1));
end

for i = 1:length(OE)
    i2 = round(OE(i)/.0001);
    w(i2+1) = t2(i2+1)-mean(t2);
end
w = cumsum(w);

tpot = (t2-mean(t2))/range(t2);
wpot = (w/range(w))-2;
OEpotx = repmat(OE,2,1);
OEpoty = [interp1(t,tpot,OE);interp1(t,wpot,OE)];

IEpotx = repmat(IE,2,1);
IEpoty = ones(size(IEpotx));
IEpoty(2,:) = interp1(t,tpot,IE);

% fignames = {'_example_potential_contribution';'_example_output_raster';...
%     '_example_input_raster';'_example_weight_change'};

f1 = figure('Position',[-1919 41 1920 963]);
hold on
for i = 1:4
    switch i
        case 1
            plot(OEpotx, OEpoty, 'm:','LineWidth',2)
            plot(OE, zeros(size(OE))-.5,'k|','MarkerSize',20,'LineWidth',3)
        case 2
            plot(IEpotx, IEpoty, 'r:','LineWidth',2)
            plot(IE, zeros(size(IE))+1,'k|','MarkerSize',20,'LineWidth',3)
        case 3
            plot(t,tpot,'k','LineWidth',3)
            yline(0)
        case 4
            plot(t,wpot,'k','LineWidth',3)
            yline(-2)
    end

%     set(f1.Children, 'box','off','LineWidth',3,'FontSize',32,'fontname','Arial','TickDir','out','XLim', [0 1])%'YTickLabel',[],'YTick',[]
%     set(f1.Children, 'box','off','LineWidth',3,'FontSize',32,'fontname','Arial','TickDir','out','XLim', [0 axmax])
%     saveas(f1,[CodeDir '\Figures\Monk' Monk fignames{i} '.emf'],'meta')
%     saveas(f1,[CodeDir '\Figures\Monk' Monk fignames{i} '.png'])
end
set(f1.Children, 'box','off','LineWidth',3,'FontSize',32,'fontname','Arial','TickDir','out','XLim', [0 1])%'YTickLabel',[],'YTick',[]
saveas(f1,[CodeDir '\Figures\Monk' Monk '_example_weight_train.emf'],'meta')
saveas(f1,[CodeDir '\Figures\Monk' Monk '_example_weight_train.png'])
close all

ClearCloseClc()

histo_allA = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_histo_all_actual_%s.mat', CodeDir, Monk, Monk, MI{2,Mkind}));
histo_allP = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_histo_all_%s.mat', CodeDir, Monk, Monk, MI{2,Mkind}));
histo_all = histo_allA.histo_all;%  #bins x #targets x #units - average actual    firing rates
histo_allP = histo_allP.histo_all;% #bins x #targets x #units - average predicted firing rates
STA = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_STA_pot_%s_%s.mat', CodeDir, Monk, Monk,MI{1,Mkind}, MI{2,Mkind}));

mean_ev = histo_allA.mean_ev;
xax_labels = histo_allA.xax_labels;


%% Below is unused analysis

%% contribution subtract expected contribution by chance.
ClearCloseClc()
chance = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_input_spike_counts_%s.mat', CodeDir, Monk, Monk,MI{2,Mkind}));
causal_in = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_EPermeg1_%s_20ms_%s.mat', CodeDir, Monk, Monk,MI{1,Mkind},MI{2,Mkind}));

[causal_in2, SCI2] = causalStruct2Mat(causal_in);
chance2 = chance.Percents;
chance2 = permute(chance2,[3,4,2,5,1]);
conmchs = causal_in2-chance2;
conmchs(isnan(conmchs))=0;
conmchs3 =  circularsmooth(conmchs ,10);


[X,Y] = meshgrid(PD_N(1:90),PD_N(1:90));
for i = 1:2
f1 = figure('Position', [-1919 41 1920 963]);
mat_ = conmchs3(:,:,i,2,2);
colormap("turbo")
surf(X*(360/(2*pi)),Y*(360/(2*pi)),mat_,'EdgeColor','none')
axis([0 360 0 360]);
pbaspect([1,1,.25])
% clim(max(abs(mat_),[],'all')*[-1, 1])
xlabel('input prefered direction (degrees)')
ylabel('target direction (degrees)')
saveas(f1,[CodeDir '\Figures\' 'Monk_' Monk '\SurfacePlots\emf\' sprintf('ContributionMinusChance_%02ims', i) '.emf'],'meta')
saveas(f1,[CodeDir '\Figures\' 'Monk_' Monk '\SurfacePlots\png\' sprintf('ContributionMinusChance_%02ims', i) '.png'])
close all
end

%% load in data for histograms without input groups
ClearCloseClc()

STA = importdata(sprintf('%s\\Data\\Monk%s\\Monk%s_STA_pot_%s_%s.mat', CodeDir, Monk, Monk,MI{1,Mkind}, MI{2,Mkind}));
for i = 1:16
    loadPath = sprintf('%s\\Data\\Monk%s\\combo%i_no-speed_output_hist_%s.mat', CodeDir, Monk,i, MI{2,Mkind});
    
    output_FR = importdata(loadPath);
    if i == 1
        histo_all = output_FR.histo_all;%  #bins x #targets x #units - average actual    firing rates
        mean_ev = output_FR.mean_ev;
        xax_labels = output_FR.xax_labels;
    else
        histo_all = cat(4, histo_all, output_FR.histo_all);
    end
end

aphist = squeeze(max(histo_all,[],[1,2,4]));
ylimset = ceil((aphist+0.05*aphist)./5).*5; ylimset =[zeros(size(ylimset)) ylimset];
for i = 1:16
    savePath = sprintf('%s\\Figures\\Monk_%s\\FRs\\combo%i_no-speed\\',...
            CodeDir, Monk,i);
    addpath(savePath)  %Where do all of the functions live?
    histo = squeeze(histo_all(:,:,:,i));
    plotFiringRates( xax_labels*1000, histo , ylimset, (mean_ev([7,12,10])*1000)-200,...
        'Firing Rate (spk/sec)', 'Time (msec)', savePath, 'A',colors);
    %with patches
    plotRatesPatches(xax_labels*1000, histo , ylimset, (mean_ev([7,12,10])*1000)-200,...
        'Firing Rate (spk/sec)', 'Time (msec)', savePath, 'A',colors, STA);
end
%% load in data for STA figure - without input groups active
ClearCloseClc()
for i = 1:16


    loadPath = sprintf('%s\\Data\\Monk%s\\combo%i_no-speed_output_pot_unit58_%s.mat', CodeDir, Monk,i, MI{2,Mkind});
    STA = importdata(loadPath);
    try
        sta = STA.sta_pot;
        threshold = STA.threshold;
        % Make 20ms STA figure
        savePath = sprintf('%s\\Figures\\Monk_%s\\STA\\combo%i_no-speed_20ms\\',...
            CodeDir, Monk,i);
        XTick = -20:2.5:0;
        XTickL = cellstr(string(XTick));
        plotSTA(sta, threshold, XTick, XTickL, (-199:0)/10, 'Membrane Potential (a.u.)', savePath, '20ms');
        
        % Make 5ms STA figure
        savePath = sprintf('%s\\Figures\\Monk_%s\\STA\\combo%i_no-speed_5ms\\',...
            CodeDir, Monk,i);
        XTick = -5:1:0;
        XTickL = cellstr(string(XTick));
        plotSTA(sta(:, end-49:end), threshold, XTick, XTickL, (-49:0)/10, 'Membrane Potential (a.u.)', savePath, '05ms');

    end
end